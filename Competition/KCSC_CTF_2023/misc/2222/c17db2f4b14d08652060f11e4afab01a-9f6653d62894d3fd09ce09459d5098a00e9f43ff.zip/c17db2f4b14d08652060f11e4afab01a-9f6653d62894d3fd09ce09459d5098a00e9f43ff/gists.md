[**Demo B company employee data**](https://gist.githubusercontent.com/truongangok/c5b1770fd1f35ddb58c9cf05c8e81f74/raw/0b69b6968d0c4eb86688843aee35b7bc63df4e8f/BK**-employee-data.json) 

[**Get hidden channel information using access token**](https://gist.githubusercontent.com/truongangok/680ebf037a08d7dfe2ef0bf3da41d9d3/raw/2f8a680077391b68e9f6c2e1f8534f5326448859/reveal.sh)

[**Get hidden channel information using access token in Python**](https://gist.githubusercontent.com/truongangok/9949f1282302231a6eecbeb231a7c350/raw/ee37cb17d88c1df35866df7d970e2bea47f93a2d/reveal.py) 