<?php
	$format_string = "[Title]: %s  [Description]: %s  [Thumbnail]: %s";

?>